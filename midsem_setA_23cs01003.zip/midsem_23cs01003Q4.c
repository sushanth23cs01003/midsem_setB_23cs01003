#include<stdio.h>
int main(){
int n ,a,b;
printf("enter the number:");
scanf("%d",&n);















    return 0;
}